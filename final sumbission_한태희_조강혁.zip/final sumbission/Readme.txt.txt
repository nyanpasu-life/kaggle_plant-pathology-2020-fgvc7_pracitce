파일 순서
image_load
데이터 구조 확인 과정

pre_distillation_train
1차 학습

distillation
1차 학습 결과를 2차 학습을 위한 레이블로 재가공

final_train
2차 학습

kfold_test
훈련 결과로 나오는 5개의 모델의 평균을 내는 작업